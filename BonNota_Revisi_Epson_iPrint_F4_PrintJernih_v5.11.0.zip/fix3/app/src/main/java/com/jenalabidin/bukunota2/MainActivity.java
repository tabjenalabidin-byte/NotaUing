package com.jenalabidin.bukunota2;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.pdf.PdfDocument;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PageRange;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.provider.ContactsContract;
import android.database.Cursor;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.ByteArrayOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER = 1001;
    private static final int CREATE_PDF = 1002;
    private static final int PICK_CONTACT = 1003;
    private static final int READ_CONTACTS_PERMISSION = 1004;
    private static final int CREATE_BACKUP = 1005;
    private static final int OPEN_BACKUP = 1006;
    private String pendingContactSearch = "";
    private String pendingPdfHtml;
    private String pendingBackupJson;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        ws.setLoadWithOverviewMode(false);
        ws.setUseWideViewPort(false);
        ws.setSupportMultipleWindows(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Tidak bisa membuka pemilih gambar.", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new PrintBridge(this), "AndroidPrint");
        webView.addJavascriptInterface(new ContactsBridge(), "AndroidContacts");
        webView.addJavascriptInterface(new BackupBridge(), "AndroidBackup");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && filePathCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        } else if (requestCode == CREATE_PDF && resultCode == RESULT_OK && data != null && data.getData() != null && pendingPdfHtml != null) {
            final Uri target = data.getData();
            final String packed = pendingPdfHtml;
            pendingPdfHtml = null;
            String html = packed; String paper = "F4";
            int marker = packed.lastIndexOf("<!--PAPER:");
            if(marker >= 0){ int end = packed.indexOf("-->", marker); if(end > marker){ paper = packed.substring(marker+10,end); html = packed.substring(0,marker); }}
            new PrintBridge(MainActivity.this).renderPdf(html, target, false, paper);
        } else if (requestCode == CREATE_PDF) {
            pendingPdfHtml = null;
        } else if (requestCode == PICK_CONTACT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            fillSelectedContact(data.getData());
        } else if (requestCode == CREATE_BACKUP && resultCode == RESULT_OK && data != null && data.getData() != null) {
            // The backup content is prepared by BackupBridge and written to the user-selected file.
            String json = pendingBackupJson;
            pendingBackupJson = null;
            if (json != null) writeBackupFile(data.getData(), json);
        } else if (requestCode == OPEN_BACKUP && resultCode == RESULT_OK && data != null && data.getData() != null) {
            readBackupFile(data.getData());
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == READ_CONTACTS_PERMISSION) {
            if (grantResults.length > 0 && grantResults[0] == android.content.pm.PackageManager.PERMISSION_GRANTED) {
                final String q = pendingContactSearch;
                pendingContactSearch = "";
                if (q != null && !q.trim().isEmpty()) {
                    new ContactsBridge().searchContacts(q);
                }
            } else {
                pendingContactSearch = "";
                runOnUiThread(() -> {
                    if (webView != null) webView.evaluateJavascript("window.showContactSuggestions && window.showContactSuggestions([]);", null);
                    Toast.makeText(MainActivity.this, "Izin kontak diperlukan untuk mencari kontak HP.", Toast.LENGTH_SHORT).show();
                });
            }
        }
    }

    @Override protected void onDestroy() {
        if (filePathCallback != null) { filePathCallback.onReceiveValue(null); filePathCallback = null; }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        // Jangan memakai WebView history untuk aplikasi SPA ini.
        // Tombol Back Android harus mengikuti tombol Kembali milik aplikasi:
        // tutup modal/preview terlebih dahulu, lalu kembali dari halaman 3 -> 2 -> 1.
        if (webView != null) {
            webView.evaluateJavascript("(function(){try{return !!androidBack();}catch(e){return false;}})()",
                    value -> {
                        if ("false".equals(value)) {
                            MainActivity.super.onBackPressed();
                        }
                    });
        } else {
            super.onBackPressed();
        }
    }

    public class ContactsBridge {
        @JavascriptInterface public void pickContact() {
            runOnUiThread(() -> {
                if (android.os.Build.VERSION.SDK_INT >= 23 &&
                        checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                    requestPermissions(new String[]{android.Manifest.permission.READ_CONTACTS}, READ_CONTACTS_PERMISSION);
                    Toast.makeText(MainActivity.this, "Izinkan akses kontak untuk memilih kontak.", Toast.LENGTH_SHORT).show();
                    return;
                }
                try {
                    Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
                    intent.addCategory(Intent.CATEGORY_DEFAULT);
                    startActivityForResult(intent, PICK_CONTACT);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Tidak bisa membuka daftar kontak.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface public void searchContacts(final String query) {
            final String q = query == null ? "" : query.trim();
            if (q.length() == 0) {
                runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript("window.showContactSuggestions && window.showContactSuggestions([]);", null); });
                return;
            }
            if (android.os.Build.VERSION.SDK_INT >= 23 &&
                    checkSelfPermission(android.Manifest.permission.READ_CONTACTS) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
                pendingContactSearch = q;
                runOnUiThread(() -> requestPermissions(new String[]{android.Manifest.permission.READ_CONTACTS}, READ_CONTACTS_PERMISSION));
                return;
            }
            new Thread(() -> {
                Cursor cursor = null;
                try {
                    Uri base = ContactsContract.CommonDataKinds.Phone.CONTENT_URI.buildUpon()
                            .appendQueryParameter("limit", "20").build();
                    String like = "%" + q.replace("%", "\\%") + "%";
                    String[] projection = new String[]{
                            ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                            ContactsContract.CommonDataKinds.Phone.NUMBER,
                            ContactsContract.CommonDataKinds.Phone.CONTACT_ID
                    };
                    String selection = ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ? OR " +
                            ContactsContract.CommonDataKinds.Phone.NUMBER + " LIKE ?";
                    cursor = getContentResolver().query(base, projection, selection,
                            new String[]{like, like}, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " COLLATE LOCALIZED ASC");
                    org.json.JSONArray arr = new org.json.JSONArray();
                    java.util.HashSet<String> seen = new java.util.HashSet<>();
                    if (cursor != null) {
                        int nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                        int numIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                        int idIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.CONTACT_ID);
                        while (cursor.moveToNext() && arr.length() < 20) {
                            String name = nameIdx >= 0 ? cursor.getString(nameIdx) : "";
                            String number = numIdx >= 0 ? cursor.getString(numIdx) : "";
                            String id = idIdx >= 0 ? cursor.getString(idIdx) : "";
                            String key = (name == null ? "" : name) + "\u0000" + (number == null ? "" : number);
                            if (!seen.add(key)) continue;
                            org.json.JSONObject item = new org.json.JSONObject();
                            item.put("name", name == null ? "" : name);
                            item.put("phone", number == null ? "" : number);
                            item.put("id", id == null ? "" : id);
                            arr.put(item);
                        }
                    }
                    final String json = arr.toString();
                    runOnUiThread(() -> {
                        if (webView != null) webView.evaluateJavascript("window.showContactSuggestions && window.showContactSuggestions(" + json + ");", null);
                    });
                } catch (Exception e) {
                    runOnUiThread(() -> {
                        if (webView != null) webView.evaluateJavascript("window.showContactSuggestions && window.showContactSuggestions([]);", null);
                    });
                } finally {
                    if (cursor != null) cursor.close();
                }
            }).start();
        }
    }

    private void writeBackupFile(Uri uri, String json) {
        try (java.io.OutputStream out = getContentResolver().openOutputStream(uri)) {
            if (out == null) throw new java.io.IOException("Output stream null");
            out.write(json.getBytes(StandardCharsets.UTF_8));
            out.flush();
            Toast.makeText(this, "Backup berhasil disimpan.", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            Toast.makeText(this, "Gagal menyimpan backup.", Toast.LENGTH_SHORT).show();
        }
    }

    private void readBackupFile(Uri uri) {
        new Thread(() -> {
            try (InputStream in = getContentResolver().openInputStream(uri); ByteArrayOutputStream buf = new ByteArrayOutputStream()) {
                if (in == null) throw new java.io.IOException("Input stream null");
                byte[] data = new byte[8192];
                int n;
                while ((n = in.read(data)) != -1) buf.write(data, 0, n);
                String json = buf.toString(StandardCharsets.UTF_8.name());
                final String safe = org.json.JSONObject.quote(json);
                runOnUiThread(() -> {
                    if (webView != null) webView.evaluateJavascript("window.restoreFromAndroidBackup && window.restoreFromAndroidBackup(" + safe + ");", null);
                });
            } catch (Exception e) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "File backup tidak bisa dibaca.", Toast.LENGTH_SHORT).show());
            }
        }).start();
    }

    public class BackupBridge {
        @JavascriptInterface public void exportBackup(String json) {
            if (json == null || json.trim().isEmpty()) {
                runOnUiThread(() -> Toast.makeText(MainActivity.this, "Tidak ada data untuk dibackup.", Toast.LENGTH_SHORT).show());
                return;
            }
            pendingBackupJson = json;
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    intent.putExtra(Intent.EXTRA_TITLE, "backup_buku_nota.json");
                    startActivityForResult(intent, CREATE_BACKUP);
                } catch (Exception e) {
                    pendingBackupJson = null;
                    Toast.makeText(MainActivity.this, "Tidak bisa membuka penyimpanan backup.", Toast.LENGTH_SHORT).show();
                }
            });
        }

        @JavascriptInterface public void importBackup() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    intent.setType("application/json");
                    startActivityForResult(intent, OPEN_BACKUP);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Tidak bisa membuka file backup.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void fillSelectedContact(Uri uri) {
        Cursor cursor = null;
        try {
            String[] projection = new String[]{
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            };
            cursor = getContentResolver().query(uri, projection, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                int numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                String name = nameIdx >= 0 ? cursor.getString(nameIdx) : "";
                String number = numberIdx >= 0 ? cursor.getString(numberIdx) : "";
                String js = "window.setContactFromAndroid(" +
                        org.json.JSONObject.quote(name == null ? "" : name) + "," +
                        org.json.JSONObject.quote(number == null ? "" : number) + ");";
                webView.evaluateJavascript(js, null);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Gagal mengambil data kontak.", Toast.LENGTH_SHORT).show();
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    public class PrintBridge {
        private final Context context;
        PrintBridge(Context context) { this.context = context; }

        @JavascriptInterface public void printPdf(final String html, final String paper) {
            runOnUiThread(() -> renderPdf(html, null, true, paper));
        }

        @JavascriptInterface public void shareImage(final String html, final String paper) {
            runOnUiThread(() -> renderImage(html, paper));
        }

        @JavascriptInterface public void savePdf(final String html, final String paper) {
            runOnUiThread(() -> {
                pendingPdfHtml = html + "\n<!--PAPER:" + paper + "-->";
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/pdf");
                i.putExtra(Intent.EXTRA_TITLE, "Buku-Nota.pdf");
                try { startActivityForResult(i, CREATE_PDF); }
                catch (Exception e) { pendingPdfHtml = null; Toast.makeText(MainActivity.this, "Tidak bisa membuka penyimpanan PDF.", Toast.LENGTH_LONG).show(); }
            });
        }

        private WebView makeRenderView(int renderScale) {
            WebView v = new WebView(MainActivity.this);
            WebSettings ws = v.getSettings();
            ws.setJavaScriptEnabled(true);
            ws.setDomStorageEnabled(false);
            ws.setAllowFileAccess(true);
            ws.setAllowContentAccess(true);
            ws.setDefaultTextEncodingName("UTF-8");
            // Native print/share rendering must use the same 1:1 CSS-pixel scale
            // as the on-screen preview. Without an explicit scale Android WebView
            // can apply the device density/initial viewport scale, making the
            // 794px A4 document appear much larger and causing the right side
            // of the nota to be cropped.
            ws.setLoadWithOverviewMode(false);
            ws.setUseWideViewPort(false);
            ws.setTextZoom(100);
            try { v.setInitialScale(Math.max(100, renderScale * 100)); } catch (Exception ignored) {}
            v.setBackgroundColor(Color.WHITE);
            v.setHorizontalScrollBarEnabled(false);
            v.setVerticalScrollBarEnabled(false);
            return v;
        }

        private void renderImage(String html, String paper) {
            final int renderScale = 2;
            final WebView v = makeRenderView(renderScale);
            final int pageWidth = paper.equals("F4") ? 813 : 794;
            final int pageHeight = paper.equals("F4") ? 1247 : 1123;
            final int renderPixelWidth = pageWidth * renderScale;
            final int renderPixelHeight = pageHeight * renderScale;
            v.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            v.setVisibility(View.VISIBLE);
            v.setTranslationX(-(pageWidth + 20));
            addContentView(v, new android.view.ViewGroup.LayoutParams(renderPixelWidth, renderPixelHeight));
            v.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) {
                    handler.postDelayed(() -> captureImagePages(v, paper, pageWidth, pageHeight), 500);
                }
            });
            v.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
        }

        /**
         * Render each physical receipt page separately.
         *
         * The old implementation made one very tall WebView and called draw()
         * on it. Android WebView does not reliably rasterize a document taller
         * than its laid-out viewport that way; depending on device/density it
         * could produce only the first part of the note. Here every .receipt-page
         * is temporarily shown alone at exactly one page height, then captured.
         */
        private void captureImagePages(final WebView view, final String paper,
                                       final int pageWidth, final int pageHeight) {
            final int renderScale = 2;
            final int renderPixelWidth = pageWidth * renderScale;
            final int renderPixelHeight = pageHeight * renderScale;
            view.evaluateJavascript("(function(){return document.querySelectorAll('.receipt-page').length||1;})()", value -> {
                int pageCount = 1;
                try { pageCount = Math.max(1, Integer.parseInt(value.replaceAll("[^0-9]", ""))); }
                catch (Exception ignored) {}

                final java.util.ArrayList<Uri> uris = new java.util.ArrayList<>();
                captureImagePage(view, paper, pageWidth, pageHeight, renderPixelWidth, renderPixelHeight, pageCount, 0, uris);
            });
        }

        private void captureImagePage(final WebView view, final String paper,
                                      final int pageWidth, final int pageHeight,
                                      final int renderPixelWidth, final int renderPixelHeight,
                                      final int pageCount, final int index,
                                      final java.util.ArrayList<Uri> uris) {
            if (index >= pageCount) {
                try {
                    Intent share = new Intent(Intent.ACTION_SEND_MULTIPLE);
                    share.setType("image/png");
                    share.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share, "Bagikan nota sebagai gambar"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Gagal membagikan gambar nota: " + e.getMessage(), Toast.LENGTH_LONG).show();
                } finally {
                    removeRenderView(view);
                }
                return;
            }

            final String showPage = "(function(){var p=document.querySelectorAll('.receipt-page');" +
                    "for(var i=0;i<p.length;i++){p[i].style.display=(i===" + index + ")?'block':'none';}" +
                    "document.documentElement.style.width='" + pageWidth + "px';" +
                    "document.body.style.width='" + pageWidth + "px';" +
                    "return true;})()";
            view.evaluateJavascript(showPage, ignored -> handler.postDelayed(() -> {
                try {
                    view.measure(View.MeasureSpec.makeMeasureSpec(renderPixelWidth, View.MeasureSpec.EXACTLY),
                            View.MeasureSpec.makeMeasureSpec(renderPixelHeight, View.MeasureSpec.EXACTLY));
                    view.layout(0, 0, renderPixelWidth, renderPixelHeight);
                    Bitmap pageBitmap = Bitmap.createBitmap(renderPixelWidth, renderPixelHeight, Bitmap.Config.ARGB_8888);
                    Canvas canvas = new Canvas(pageBitmap);
                    canvas.drawColor(Color.WHITE);
                    view.draw(canvas);

                    File dir = new File(getCacheDir(), "shared");
                    if (!dir.exists()) dir.mkdirs();
                    File file = new File(dir, "Buku-Nota-" + System.currentTimeMillis() + "-" + (index + 1) + ".png");
                    try (FileOutputStream out = new FileOutputStream(file)) {
                        pageBitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                    }
                    pageBitmap.recycle();
                    uris.add(FileProvider.getUriForFile(MainActivity.this,
                            getPackageName() + ".fileprovider", file));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Gagal merender halaman " + (index + 1) + ": " + e.getMessage(), Toast.LENGTH_LONG).show();
                    removeRenderView(view);
                    return;
                }
                captureImagePage(view, paper, pageWidth, pageHeight, renderPixelWidth, renderPixelHeight, pageCount, index + 1, uris);
            }, 80));
        }

        /**
         * Send the rendered WebView directly to Android PrintManager.
         * This avoids rasterizing the nota into a bitmap and keeps text, lines,
         * logo and signature sharp at the printer's native resolution.
         */
        private void renderPdfVector(final String html, final Uri target, final boolean sendToEpson, final String paper) {
            if (!sendToEpson) {
                renderPdf(html, target, false, paper);
                return;
            }

            final WebView v = makeRenderView(1);
            v.setVisibility(View.VISIBLE);
            v.setTranslationX(-1200);
            addContentView(v, new android.view.ViewGroup.LayoutParams(2, 2));
            v.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) {
                    handler.postDelayed(() -> {
                        try {
                            final PrintDocumentAdapter nativeAdapter = v.createPrintDocumentAdapter("Bon Nota");
                            final PrintAttributes.MediaSize media = new PrintAttributes.MediaSize(
                                    "BON_NOTA_F4", "F4", 8465, 12992);
                            final PrintAttributes attrs = new PrintAttributes.Builder()
                                    .setMediaSize(media)
                                    .setResolution(new PrintAttributes.Resolution(
                                            "BON_NOTA_600", "Bon Nota 600dpi", 600, 600))
                                    .setMinMargins(new PrintAttributes.Margins(0, 0, 0, 0))
                                    .setColorMode(PrintAttributes.COLOR_MODE_COLOR)
                                    .build();

                            // Wrap the WebView adapter so Android's PrintManager supplies
                            // the framework-owned LayoutResultCallback/WriteResultCallback.
                            // Do NOT instantiate WriteResultCallback ourselves: its constructor
                            // is not public on Android and that caused the previous build error.
                            PrintDocumentAdapter printAdapter = new PrintDocumentAdapter() {
                                @Override public void onStart() { nativeAdapter.onStart(); }
                                @Override public void onLayout(PrintAttributes oldAttributes,
                                        PrintAttributes newAttributes, CancellationSignal cancellationSignal,
                                        LayoutResultCallback callback, Bundle extras) {
                                    nativeAdapter.onLayout(oldAttributes, newAttributes, cancellationSignal, callback, extras);
                                }
                                @Override public void onWrite(PageRange[] pages, ParcelFileDescriptor destination,
                                        CancellationSignal cancellationSignal, WriteResultCallback callback) {
                                    nativeAdapter.onWrite(pages, destination, cancellationSignal, callback);
                                }
                                @Override public void onFinish() {
                                    try { nativeAdapter.onFinish(); } catch (Exception ignored) {}
                                    removeRenderView(v);
                                }
                            };

                            PrintManager printManager = (PrintManager) getSystemService(Context.PRINT_SERVICE);
                            if (printManager == null) {
                                Toast.makeText(MainActivity.this, "Layanan cetak Android tidak tersedia.", Toast.LENGTH_LONG).show();
                                removeRenderView(v);
                                return;
                            }
                            printManager.print("Bon Nota", printAdapter, attrs);
                        } catch (Exception e) {
                            Toast.makeText(MainActivity.this, "Gagal membuka cetak: " + e.getMessage(), Toast.LENGTH_LONG).show();
                            removeRenderView(v);
                        }
                    }, 400);
                }
            });
            v.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
        }

        private void renderPdf(String html, Uri target, boolean sendToEpson, String paper) {
            final int renderScale = 4;
            final WebView v = makeRenderView(renderScale);
            final int renderWidth = paper.equals("F4") ? 813 : 794;
            final int renderHeight = paper.equals("F4") ? 1247 : 1123;
            final int renderPixelWidth = renderWidth * renderScale;
            final int renderPixelHeight = renderHeight * renderScale;
            v.setLayerType(View.LAYER_TYPE_SOFTWARE, null);
            v.setVisibility(View.VISIBLE);
            v.setTranslationX(-(renderWidth + 40));
            addContentView(v, new android.view.ViewGroup.LayoutParams(renderPixelWidth, renderPixelHeight));
            v.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) {
                    handler.postDelayed(() -> prepareFullPagePdf(v, target, sendToEpson, paper, renderWidth, renderHeight, renderPixelWidth, renderPixelHeight), 700);
                }
            });
            v.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
        }

        private void prepareFullPagePdf(final WebView view, final Uri target, final boolean sendToEpson,
                                        final String paper, final int pageWidth, final int pageHeight,
                                        final int renderPixelWidth, final int renderPixelHeight) {
            view.evaluateJavascript("(function(){return document.querySelectorAll('.receipt-page').length||1;})()", value -> {
                int pageCount = 1;
                try { pageCount = Math.max(1, Integer.parseInt(value.replaceAll("[^0-9]", ""))); }
                catch (Exception ignored) {}
                PdfDocument pdf = new PdfDocument();
                capturePdfPage(view, pdf, target, sendToEpson, paper, pageWidth, pageHeight, renderPixelWidth, renderPixelHeight, pageCount, 0);
            });
        }

        /** Capture one HTML page at a time and add it to the PDF. */
        private void capturePdfPage(final WebView view, final PdfDocument pdf,
                                    final Uri target, final boolean sendToEpson,
                                    final String paper, final int pageWidth, final int pageHeight,
                                    final int renderPixelWidth, final int renderPixelHeight,
                                    final int pageCount, final int index) {
            if (index >= pageCount) {
                finishPagedPdf(pdf, target, sendToEpson, view, paper);
                return;
            }

            final String showPage = "(function(){var p=document.querySelectorAll('.receipt-page');" +
                    "for(var i=0;i<p.length;i++){p[i].style.display=(i===" + index + ")?'block':'none';}" +
                    "document.documentElement.style.width='" + pageWidth + "px';" +
                    "document.body.style.width='" + pageWidth + "px';" +
                    "return true;})()";
            view.evaluateJavascript(showPage, ignored -> handler.postDelayed(() -> {
                try {
                    view.measure(View.MeasureSpec.makeMeasureSpec(renderPixelWidth, View.MeasureSpec.EXACTLY),
                            View.MeasureSpec.makeMeasureSpec(renderPixelHeight, View.MeasureSpec.EXACTLY));
                    view.layout(0, 0, renderPixelWidth, renderPixelHeight);
                    Bitmap bitmap = Bitmap.createBitmap(renderPixelWidth, renderPixelHeight, Bitmap.Config.ARGB_8888);
                    Canvas canvas = new Canvas(bitmap);
                    canvas.drawColor(Color.WHITE);
                    view.draw(canvas);

                    // Keep the PDF page itself at true F4 size (8.5 x 13 in = 612 x 936 pt).
                    // The WebView is rendered at 4x before being placed on the PDF,
                    // so Epson iPrint receives a much sharper source than the old 2x render.
                    final int pdfWidth = paper.equals("F4") ? 612 : 595;
                    final int pdfHeight = paper.equals("F4") ? 936 : 842;
                    PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(pdfWidth, pdfHeight, index + 1).create();
                    PdfDocument.Page page = pdf.startPage(info);
                    Canvas pc = page.getCanvas();
                    pc.drawColor(Color.WHITE);
                    android.graphics.Paint pdfPaint = new android.graphics.Paint(android.graphics.Paint.ANTI_ALIAS_FLAG | android.graphics.Paint.FILTER_BITMAP_FLAG);
                    pc.drawBitmap(bitmap, null, new android.graphics.RectF(0, 0, pdfWidth, pdfHeight), pdfPaint);
                    pdf.finishPage(page);
                    bitmap.recycle();
                } catch (Exception e) {
                    try { pdf.close(); } catch (Exception ignored2) {}
                    Toast.makeText(MainActivity.this, "Gagal merender halaman PDF " + (index + 1) + ": " + e.getMessage(), Toast.LENGTH_LONG).show();
                    removeRenderView(view);
                    return;
                }
                capturePdfPage(view, pdf, target, sendToEpson, paper, pageWidth, pageHeight, renderPixelWidth, renderPixelHeight, pageCount, index + 1);
            }, 80));
        }

        private void finishPagedPdf(PdfDocument pdf, Uri target, boolean sendToEpson,
                                    WebView view, String paper) {
            File temp = null;
            try {
                File dir = new File(getCacheDir(), "shared");
                if (!dir.exists()) dir.mkdirs();
                temp = new File(dir, "Buku-Nota-" + System.currentTimeMillis() + ".pdf");
                try (FileOutputStream out = new FileOutputStream(temp)) { pdf.writeTo(out); }
                finishPdfExport(temp, target, sendToEpson, view);
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Gagal membuat PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
                if (temp != null) temp.delete();
                removeRenderView(view);
            } finally {
                try { pdf.close(); } catch (Exception ignored) {}
            }
        }

        private void finishPdfExport(File temp, Uri target, boolean sendToEpson, WebView view) {
            try {
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", temp);
                if (target != null) {
                    try (java.io.OutputStream out = getContentResolver().openOutputStream(target);
                         java.io.InputStream in = new java.io.FileInputStream(temp)) {
                        byte[] buf = new byte[8192]; int n;
                        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    }
                    Toast.makeText(MainActivity.this, "PDF berhasil disimpan.", Toast.LENGTH_SHORT).show();
                } else if (sendToEpson) {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("application/pdf");
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    if (isPackageInstalled("epson.print")) {
                        send.setPackage("epson.print");
                        try { startActivity(send); }
                        catch (Exception e) { shareChooser(uri, "Kirim PDF nota ke Epson iPrint"); }
                    } else {
                        shareChooser(uri, "Kirim PDF nota ke Epson iPrint");
                    }
                }
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Gagal mengekspor PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
            } finally {
                removeRenderView(view);
            }
        }

        private void shareChooser(Uri uri, String title) {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("application/pdf");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, title));
        }
        private void removeRenderView(View v) {
            if (v.getParent() instanceof android.view.ViewGroup) ((android.view.ViewGroup)v.getParent()).removeView(v);
        }
        private boolean isPackageInstalled(String packageName) {
            try { getPackageManager().getPackageInfo(packageName, 0); return true; }
            catch (Exception e) { return false; }
        }
    }
}
