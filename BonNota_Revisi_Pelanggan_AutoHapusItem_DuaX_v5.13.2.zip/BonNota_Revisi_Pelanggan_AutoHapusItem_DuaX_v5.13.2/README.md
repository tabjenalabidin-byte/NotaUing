
# Bon Nota v5.10.0

Perbaikan: tombol hapus hanya di Daftar Nota, dan Print menggunakan Android PrintManager + WebView native adapter agar hasil cetak tajam. Kertas F4 tetap.

# Bon Nota — v5.9.7

Project ini mempertahankan package/application ID yang digunakan aplikasi lama:
`com.jenalabidin.bukunota2`

## Fitur yang dipertahankan
- Format nota maksimal 40 item per lembar.
- Tabel dan ukuran huruf menyesuaikan jumlah item.
- TOTAL, ONGKIR, BAYAR, dan SISA tetap berada di bagian nota, bukan footer.
- Tanda tangan tetap berada di bagian nota.
- Footer paling bawah hanya tulisan hukum dan `*** Thank You ***`.
- Pencarian kontak HP saat mengetik nama pelanggan dan pemilihan nomor kontak.
- Backup & Restore data aplikasi ke/dari file JSON.
- Preview, PDF, share, dan cetak Epson tetap dipertahankan.

## Penting tentang update aplikasi lama
Package ID yang sama **belum cukup** untuk membuat APK baru menjadi update. Android juga memerlukan signing key yang sama. APK lama yang dikirim sebagai `BukuNota-APK (12).zip` hanya berisi APK dan tidak berisi private signing key. Karena itu private key lama tidak dapat dipulihkan dari APK.

Workflow GitHub pada project ini sengaja **menolak build** jika signing secrets belum tersedia, supaya tidak menghasilkan APK debug baru yang kemudian bentrok dengan aplikasi lama.

## Signing GitHub Actions
Tambahkan 4 repository secrets berikut menggunakan keystore yang memang digunakan untuk APK yang sudah terpasang:
- `KEYSTORE_BASE64`
- `KEYSTORE_PASSWORD`
- `KEY_ALIAS`
- `KEY_PASSWORD`

Workflow kemudian membuat `signing.keystore` sementara dan menghasilkan `app-release.apk`. Jika signing key benar-benar sama dengan aplikasi lama, APK tersebut dapat dipasang sebagai update dan data aplikasi lama tetap dipertahankan.

Jika signing key lama tidak tersedia, jangan uninstall aplikasi lama. Gunakan fitur Backup & Restore pada versi yang dapat dijalankan untuk memindahkan data ke instalasi baru.


### v5.12.0 — Epson iPrint
- Tombol Cetak Epson sekarang langsung mengirim PDF ke Epson iPrint, tanpa membuka Android Print Manager.
- Ukuran halaman tetap F4 (210 × 330 mm / 8.5 × 13 in).
- Render PDF dinaikkan menjadi 4× sebelum ditempatkan ke halaman PDF untuk menjaga hasil cetak lebih tajam.


### v5.12.0 - Print PDF Vektor ke Epson iPrint
- Tombol Cetak pada Preview menggunakan WebView native PrintDocumentAdapter untuk membuat PDF vektor.
- Tidak lagi menggunakan jalur Bitmap -> PDF untuk cetak, sehingga teks/garis tidak dirasterisasi.
- Ukuran media cetak dikunci F4 215 x 330 mm saat membuat PDF.
- PDF hasil kemudian dikirim langsung ke Epson iPrint (package `epson.print`).


## v5.13.2
- Menambahkan tombol **× Hapus** pada setiap item di halaman Daftar Item.
- Tombol menghapus item yang dipilih setelah konfirmasi dan langsung menyimpan perubahan.
- Fitur Edit Item tetap tersedia.


Fitur hapus: tanda × tersedia pada Daftar Nota dan Daftar Item.
