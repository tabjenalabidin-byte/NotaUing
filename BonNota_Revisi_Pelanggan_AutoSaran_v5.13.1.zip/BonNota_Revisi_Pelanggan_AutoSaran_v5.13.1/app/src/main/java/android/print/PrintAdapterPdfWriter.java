package android.print;

import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;

import java.io.File;

/**
 * Small bridge kept in the android.print package so it can instantiate the
 * framework's hidden/package-private callback constructors. Android exposes
 * the callback methods publicly but intentionally hides their constructors.
 */
public final class PrintAdapterPdfWriter {
    private PrintAdapterPdfWriter() {}

    public interface Completion {
        void onSuccess();
        void onFailure(CharSequence error);
        void onCancelled();
    }

    public static void writeToFile(final PrintDocumentAdapter adapter,
                                   final PrintAttributes attrs,
                                   final File output,
                                   final Completion completion) {
        try {
            adapter.onStart();
            adapter.onLayout(null, attrs, new CancellationSignal(),
                    new PrintDocumentAdapter.LayoutResultCallback() {
                        @Override public void onLayoutFinished(PrintDocumentInfo info, boolean changed) {
                            try {
                                final ParcelFileDescriptor pfd = ParcelFileDescriptor.open(
                                        output,
                                        ParcelFileDescriptor.MODE_CREATE
                                                | ParcelFileDescriptor.MODE_TRUNCATE
                                                | ParcelFileDescriptor.MODE_WRITE_ONLY);
                                adapter.onWrite(new PageRange[]{PageRange.ALL_PAGES}, pfd,
                                        new CancellationSignal(),
                                        new PrintDocumentAdapter.WriteResultCallback() {
                                            @Override public void onWriteFinished(PageRange[] pages) {
                                                try { pfd.close(); } catch (Exception ignored) {}
                                                try { adapter.onFinish(); } catch (Exception ignored) {}
                                                completion.onSuccess();
                                            }

                                            @Override public void onWriteFailed(CharSequence error) {
                                                try { pfd.close(); } catch (Exception ignored) {}
                                                try { adapter.onFinish(); } catch (Exception ignored) {}
                                                completion.onFailure(error);
                                            }

                                            @Override public void onWriteCancelled() {
                                                try { pfd.close(); } catch (Exception ignored) {}
                                                try { adapter.onFinish(); } catch (Exception ignored) {}
                                                completion.onCancelled();
                                            }
                                        });
                            } catch (Exception e) {
                                try { adapter.onFinish(); } catch (Exception ignored) {}
                                completion.onFailure(e.getMessage());
                            }
                        }

                        @Override public void onLayoutFailed(CharSequence error) {
                            try { adapter.onFinish(); } catch (Exception ignored) {}
                            completion.onFailure(error);
                        }

                        @Override public void onLayoutCancelled() {
                            try { adapter.onFinish(); } catch (Exception ignored) {}
                            completion.onCancelled();
                        }
                    }, (Bundle) null);
        } catch (Exception e) {
            try { adapter.onFinish(); } catch (Exception ignored) {}
            completion.onFailure(e.getMessage());
        }
    }
}
