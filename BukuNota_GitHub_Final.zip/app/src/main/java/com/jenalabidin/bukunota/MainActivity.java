package com.jenalabidin.bukunota;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.view.View;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private final Handler handler = new Handler(Looper.getMainLooper());

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        ws.setLoadWithOverviewMode(false);
        ws.setUseWideViewPort(false);

        webView.setWebViewClient(new WebViewClient());
        webView.addJavascriptInterface(new PrintBridge(this), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    private static String escapeForJs(String s) {
        return s.replace("\\", "\\\\").replace("'", "\\'").replace("\n", "\\n").replace("\r", "\\r");
    }

    public class PrintBridge {
        private final Context context;
        PrintBridge(Context context) { this.context = context; }

        @JavascriptInterface
        public void printHtml(final String html) {
            runOnUiThread(() -> {
                final WebView printView = makePrintView(html);
                printView.setVisibility(View.INVISIBLE);
                addContentView(printView, new android.view.ViewGroup.LayoutParams(794, 1123));
                printView.setBackgroundColor(android.graphics.Color.WHITE);
                printView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        handler.postDelayed(() -> {
                            PrintManager pm = (PrintManager) getSystemService(PRINT_SERVICE);
                            PrintAttributes attrs = new PrintAttributes.Builder()
                                    .setMediaSize(PrintAttributes.MediaSize.ISO_A4)
                                    .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                                    .build();
                            pm.print("Buku Nota", view.createPrintDocumentAdapter("Buku Nota"), attrs);
                        }, 350);
                    }
                });
                printView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            });
        }

        @JavascriptInterface
        public void shareImage(final String html) {
            runOnUiThread(() -> {
                final WebView shareView = makePrintView(html);
                shareView.setVisibility(View.INVISIBLE);
                addContentView(shareView, new android.view.ViewGroup.LayoutParams(794, 1123));
                shareView.setWebViewClient(new WebViewClient() {
                    @Override public void onPageFinished(WebView view, String url) {
                        handler.postDelayed(() -> captureAndShare(view), 450);
                    }
                });
                shareView.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
            });
        }

        private WebView makePrintView(String html) {
            WebView v = new WebView(MainActivity.this);
            WebSettings ws = v.getSettings();
            ws.setJavaScriptEnabled(false);
            ws.setDomStorageEnabled(false);
            ws.setAllowFileAccess(true);
            ws.setAllowContentAccess(true);
            ws.setDefaultTextEncodingName("UTF-8");
            v.setBackgroundColor(android.graphics.Color.WHITE);
            return v;
        }

        private void captureAndShare(WebView view) {
            int width = 794;
            int height = Math.max(1123, view.getContentHeight() * Math.max(1, (int)view.getScale()));
            height = Math.min(height, 5000);

            view.measure(
                    View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.AT_MOST)
            );
            view.layout(0, 0, width, Math.min(height, Math.max(1, view.getContentHeight())));
            int actualHeight = Math.max(view.getHeight(), 1);

            Bitmap bitmap = Bitmap.createBitmap(width, actualHeight, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            canvas.drawColor(android.graphics.Color.WHITE);
            view.draw(canvas);

            try {
                File dir = new File(getCacheDir(), "shared");
                if (!dir.exists()) dir.mkdirs();
                File file = new File(dir, "nota-" + System.currentTimeMillis() + ".png");
                try (FileOutputStream out = new FileOutputStream(file)) {
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                }

                Uri uri = FileProvider.getUriForFile(
                        MainActivity.this,
                        getPackageName() + ".fileprovider",
                        file
                );

                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("image/png");
                share.putExtra(Intent.EXTRA_STREAM, uri);
                share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

                if (isPackageInstalled("com.whatsapp")) {
                    share.setPackage("com.whatsapp");
                    startActivity(share);
                } else if (isPackageInstalled("com.whatsapp.w4b")) {
                    share.setPackage("com.whatsapp.w4b");
                    startActivity(share);
                } else {
                    startActivity(Intent.createChooser(share, "Bagikan nota"));
                }
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Gagal membuat gambar nota: " + e.getMessage(), Toast.LENGTH_LONG).show();
            } finally {
                bitmap.recycle();
                ((android.view.ViewGroup) view.getParent()).removeView(view);
            }
        }

        private boolean isPackageInstalled(String packageName) {
            try {
                getPackageManager().getPackageInfo(packageName, 0);
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }
}
