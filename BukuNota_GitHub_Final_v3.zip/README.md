# Buku Nota APK

Versi revisi:
- Bagikan preview nota sebagai gambar langsung ke WhatsApp/WhatsApp Business.
- Enter pada keyboard berpindah ke field berikutnya.
- Halaman terakhir dibuka kembali saat aplikasi dijalankan.
- Draft nota disimpan otomatis agar tidak mudah hilang saat aplikasi tertutup.
- Cetak menggunakan Android Print Framework native, dengan fallback `window.print()` jika HTML dibuka di browser.

## Build di GitHub
1. Upload seluruh isi folder proyek ini ke repository GitHub.
2. Pastikan branch utama bernama `main` atau `master`.
3. Buka **Actions → Build APK**.
4. Jalankan workflow dengan **Run workflow** atau push ke branch.
5. APK tersedia di artifact **BukuNota-APK**.
