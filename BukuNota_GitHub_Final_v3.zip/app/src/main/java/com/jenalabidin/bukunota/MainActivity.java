package com.jenalabidin.bukunota;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.print.PrintAttributes;
import android.print.PrintManager;
import android.view.View;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private ValueCallback<Uri[]> filePathCallback;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);

        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        ws.setLoadWithOverviewMode(false);
        ws.setUseWideViewPort(false);
        ws.setSupportMultipleWindows(false);

        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView webView, ValueCallback<Uri[]> callback,
                                             FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, 1001);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Tidak bisa membuka pemilih gambar.", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });

        webView.addJavascriptInterface(new PrintBridge(this), "AndroidPrint");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1001 && filePathCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        }
    }

    @Override
    protected void onDestroy() {
        if (filePathCallback != null) {
            filePathCallback.onReceiveValue(null);
            filePathCallback = null;
        }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override
    public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack();
        else super.onBackPressed();
    }

    public class PrintBridge {
        private final Context context;
        PrintBridge(Context context) { this.context = context; }

        @JavascriptInterface
        public void printHtml(final String html) {
            runOnUiThread(() -> {
                // Prefer Epson iPrint: Epson documents support sharing PDF/images to iPrint,
                // while Android's generic Print Spooler can show printer-specific errors.
                renderToPngAndSendToEpson(html, true);
            });
        }

        @JavascriptInterface
        public void shareImage(final String html) {
            runOnUiThread(() -> renderToPngAndSendToEpson(html, false));
        }

        private WebView makeRenderView(String html) {
            WebView v = new WebView(MainActivity.this);
            WebSettings ws = v.getSettings();
            ws.setJavaScriptEnabled(false);
            ws.setDomStorageEnabled(false);
            ws.setAllowFileAccess(true);
            ws.setAllowContentAccess(true);
            ws.setDefaultTextEncodingName("UTF-8");
            v.setBackgroundColor(Color.WHITE);
            return v;
        }

        private void renderToPngAndSendToEpson(String html, boolean printMode) {
            final WebView v = makeRenderView(html);
            v.setVisibility(View.INVISIBLE);
            addContentView(v, new android.view.ViewGroup.LayoutParams(1240, 100));
            v.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) {
                    handler.postDelayed(() -> captureFullPage(v, printMode), 700);
                }
            });
            v.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
        }

        private void captureFullPage(WebView view, boolean printMode) {
            final int width = 1240;
            int contentHeight = Math.max(1, view.getContentHeight());
            float scale = view.getScale();
            int height = Math.max(1, (int) Math.ceil(contentHeight * Math.max(1f, scale)));
            height = Math.min(height, 9000);

            // Measure and layout the entire document, not the visible screen viewport.
            view.measure(
                    View.MeasureSpec.makeMeasureSpec(width, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(height, View.MeasureSpec.EXACTLY)
            );
            view.layout(0, 0, width, height);

            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            canvas.drawColor(Color.WHITE);
            view.draw(canvas);

            File file = null;
            try {
                File dir = new File(getCacheDir(), "shared");
                if (!dir.exists()) dir.mkdirs();
                file = new File(dir, "Buku-Nota-" + System.currentTimeMillis() + ".png");
                try (FileOutputStream out = new FileOutputStream(file)) {
                    bitmap.compress(Bitmap.CompressFormat.PNG, 100, out);
                }

                Uri uri = FileProvider.getUriForFile(
                        MainActivity.this,
                        getPackageName() + ".fileprovider",
                        file
                );

                if (printMode) {
                    if (isPackageInstalled("epson.print")) {
                        Intent send = new Intent(Intent.ACTION_SEND);
                        send.setType("image/png");
                        send.putExtra(Intent.EXTRA_STREAM, uri);
                        send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                        send.setPackage("epson.print");
                        try {
                            startActivity(send);
                        } catch (Exception e) {
                            shareChooser(uri, "Kirim nota ke Epson iPrint untuk dicetak");
                        }
                    } else {
                        Toast.makeText(MainActivity.this,
                                "Epson iPrint belum terpasang. Pilih Epson iPrint dari menu Bagikan atau instal Epson iPrint terlebih dahulu.",
                                Toast.LENGTH_LONG).show();
                        shareChooser(uri, "Kirim nota untuk dicetak");
                    }
                } else {
                    shareChooser(uri, "Bagikan nota");
                }
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Gagal membuat gambar nota: " + e.getMessage(), Toast.LENGTH_LONG).show();
            } finally {
                bitmap.recycle();
                if (view.getParent() instanceof android.view.ViewGroup) {
                    ((android.view.ViewGroup) view.getParent()).removeView(view);
                }
            }
        }

        private void shareChooser(Uri uri, String title) {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("image/png");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, title));
        }

        private boolean isPackageInstalled(String packageName) {
            try {
                getPackageManager().getPackageInfo(packageName, 0);
                return true;
            } catch (Exception e) {
                return false;
            }
        }
    }
}
