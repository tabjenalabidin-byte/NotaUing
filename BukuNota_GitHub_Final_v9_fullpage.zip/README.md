# Buku Nota APK - v6

Perubahan:
- Mengembalikan menu **📒 Telusuri Kontak** pada formulir pelanggan.
- Tombol membuka daftar kontak Android dan mengisi **Nama** serta **Nomor Kontak/WhatsApp** otomatis.
- Tetap mempertahankan fitur A4/F4, Preview, Bagikan WhatsApp, Simpan PDF, Cetak Epson/iPrint, logo/tanda tangan, Enter navigation, draft otomatis, dan edit nota/timbangan.
- Memperbaiki duplikasi deklarasi `File dir` pada MainActivity agar source build tidak gagal karena deklarasi lokal ganda.
- Version 5.0 / versionCode 5.

Build melalui GitHub Actions.
