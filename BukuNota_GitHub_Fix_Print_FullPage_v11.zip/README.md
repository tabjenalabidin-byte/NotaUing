# Buku Nota APK — v10 Full Page A4/F4

Versi ini memperbaiki ukuran hasil Preview, gambar WhatsApp, PDF, dan cetak Epson agar benar-benar berupa **satu halaman penuh A4 atau F4**, bukan screenshot WebView yang melebar/terpotong.

## Ukuran halaman
- A4: 794 × 1123 px (rasio A4), PDF 595 × 842 pt
- F4: 813 × 1247 px (rasio F4), PDF 612 × 936 pt

## Perbaikan utama
- Gambar WhatsApp dibuat tepat satu halaman A4/F4.
- PDF dibuat tepat satu halaman A4/F4 dan seluruh halaman diskalakan agar muat.
- Cetak Epson menggunakan PDF halaman penuh.
- Preview memakai lebar halaman responsif agar tidak melebar keluar layar.
- Kolom pelanggan dan tabel menggunakan layout yang lebih aman agar tidak terpotong di sisi kanan.

Fitur sebelumnya tetap dipertahankan: Telusuri Kontak, logo/tanda tangan, Enter pindah field, draft otomatis, edit item/timbangan, A4/F4, WhatsApp, Simpan PDF, dan Cetak Epson.


## Perbaikan v11 — WebView density / hasil hanya separuh
Pada perangkat Android dengan density tinggi, hasil Cetak Epson, Simpan PDF, dan Bagikan WhatsApp sebelumnya dapat terlihat hanya sebagian (misalnya logo/nama di bagian atas saja). Penyebabnya adalah ukuran WebView dihitung sebagai piksel fisik, sedangkan HTML menggunakan CSS pixel. Versi ini merender WebView pada ukuran CSS × density perangkat, kemudian mengecilkannya kembali menjadi satu halaman A4/F4.
