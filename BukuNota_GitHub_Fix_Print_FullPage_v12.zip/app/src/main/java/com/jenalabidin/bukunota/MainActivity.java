package com.jenalabidin.bukunota;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.pdf.PdfDocument;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.provider.ContactsContract;
import android.database.Cursor;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    static { WebView.enableSlowWholeDocumentDraw(); }
    private WebView webView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER = 1001;
    private static final int CREATE_PDF = 1002;
    private static final int PICK_CONTACT = 1003;
    private String pendingPdfHtml;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        ws.setLoadWithOverviewMode(false);
        ws.setUseWideViewPort(false);
        ws.setSupportMultipleWindows(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Tidak bisa membuka pemilih gambar.", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new PrintBridge(this), "AndroidPrint");
        webView.addJavascriptInterface(new ContactsBridge(), "AndroidContacts");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && filePathCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        } else if (requestCode == CREATE_PDF && resultCode == RESULT_OK && data != null && data.getData() != null && pendingPdfHtml != null) {
            final Uri target = data.getData();
            final String packed = pendingPdfHtml;
            pendingPdfHtml = null;
            String html = packed; String paper = "A4";
            int marker = packed.lastIndexOf("<!--PAPER:");
            if(marker >= 0){ int end = packed.indexOf("-->", marker); if(end > marker){ paper = packed.substring(marker+10,end); html = packed.substring(0,marker); }}
            new PrintBridge(MainActivity.this).renderPdf(html, target, false, paper);
        } else if (requestCode == CREATE_PDF) {
            pendingPdfHtml = null;
        } else if (requestCode == PICK_CONTACT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            fillSelectedContact(data.getData());
        }
    }

    @Override protected void onDestroy() {
        if (filePathCallback != null) { filePathCallback.onReceiveValue(null); filePathCallback = null; }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public class ContactsBridge {
        @JavascriptInterface public void pickContact() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
                    intent.addCategory(Intent.CATEGORY_DEFAULT);
                    startActivityForResult(intent, PICK_CONTACT);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Tidak bisa membuka daftar kontak.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void fillSelectedContact(Uri uri) {
        Cursor cursor = null;
        try {
            String[] projection = new String[]{
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            };
            cursor = getContentResolver().query(uri, projection, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                int numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                String name = nameIdx >= 0 ? cursor.getString(nameIdx) : "";
                String number = numberIdx >= 0 ? cursor.getString(numberIdx) : "";
                String js = "window.setContactFromAndroid(" +
                        org.json.JSONObject.quote(name == null ? "" : name) + "," +
                        org.json.JSONObject.quote(number == null ? "" : number) + ");";
                webView.evaluateJavascript(js, null);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Gagal mengambil data kontak.", Toast.LENGTH_SHORT).show();
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    public class PrintBridge {
        private final Context context;
        PrintBridge(Context context) { this.context = context; }

        @JavascriptInterface public void printPdf(final String html, final String paper) {
            runOnUiThread(() -> {
                // Epson iPrint accepts PDF documents. We create a real A4 PDF instead of
                // sending a very tall PNG, avoiding the 10x15-photo scaling/cropping seen before.
                renderPdf(html, null, true, paper);
            });
        }

        @JavascriptInterface public void shareImage(final String html, final String paper) {
            runOnUiThread(() -> renderImage(html, paper));
        }

        @JavascriptInterface public void savePdf(final String html, final String paper) {
            runOnUiThread(() -> {
                pendingPdfHtml = html + "\n<!--PAPER:" + paper + "-->";
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/pdf");
                i.putExtra(Intent.EXTRA_TITLE, "Buku-Nota.pdf");
                try { startActivityForResult(i, CREATE_PDF); }
                catch (Exception e) { pendingPdfHtml = null; Toast.makeText(MainActivity.this, "Tidak bisa membuka penyimpanan PDF.", Toast.LENGTH_LONG).show(); }
            });
        }

        private WebView makeRenderView() {
            WebView v = new WebView(MainActivity.this);
            WebSettings ws = v.getSettings();
            ws.setJavaScriptEnabled(false);
            ws.setDomStorageEnabled(false);
            ws.setAllowFileAccess(true);
            ws.setAllowContentAccess(true);
            ws.setDefaultTextEncodingName("UTF-8");
            v.setBackgroundColor(Color.WHITE);
            return v;
        }

        private void renderImage(String html, String paper) {
            final WebView v = makeRenderView();
            v.setVisibility(View.INVISIBLE);
            final int cssWidth = paper.equals("F4") ? 813 : 794;
            final int cssHeight = paper.equals("F4") ? 1247 : 1123;
            final float density = getResources().getDisplayMetrics().density;
            final int renderWidth = Math.round(cssWidth * density);
            final int renderHeight = Math.round(cssHeight * density);
            addContentView(v, new android.view.ViewGroup.LayoutParams(renderWidth, renderHeight));
            v.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) {
                    handler.postDelayed(() -> captureFullImage(v, paper), 500);
                }
            });
            v.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
        }

        private void captureFullImage(WebView view, String paper) {
            // IMPORTANT: Android WebView CSS pixels are density-aware.
            // The previous code measured the WebView at 794/813 physical px,
            // while the HTML page itself was 794/813 CSS px wide. On phones
            // with density > 1 this made only the left/top part visible.
            // Render at the device-density size, then scale back to one page.
            final int cssWidth = paper.equals("F4") ? 813 : 794;
            final int cssHeight = paper.equals("F4") ? 1247 : 1123;
            final float density = getResources().getDisplayMetrics().density;
            final int renderWidth = Math.round(cssWidth * density);
            final int renderHeight = Math.round(cssHeight * density);

            view.measure(View.MeasureSpec.makeMeasureSpec(renderWidth, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(renderHeight, View.MeasureSpec.EXACTLY));
            view.layout(0, 0, renderWidth, renderHeight);
            view.requestLayout();

            Bitmap bitmap = Bitmap.createBitmap(cssWidth, cssHeight, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            canvas.drawColor(Color.WHITE);
            canvas.save();
            canvas.scale(1f / density, 1f / density);
            view.draw(canvas);
            canvas.restore();
            File file = null;
            try {
                File dir = new File(getCacheDir(), "shared"); if (!dir.exists()) dir.mkdirs();
                file = new File(dir, "Buku-Nota-" + System.currentTimeMillis() + ".png");
                try (FileOutputStream out = new FileOutputStream(file)) { bitmap.compress(Bitmap.CompressFormat.PNG, 100, out); }
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", file);
                Intent share = new Intent(Intent.ACTION_SEND);
                share.setType("image/png");
                share.putExtra(Intent.EXTRA_STREAM, uri);
                share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                startActivity(Intent.createChooser(share, "Bagikan nota sebagai gambar"));
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Gagal membuat gambar nota: " + e.getMessage(), Toast.LENGTH_LONG).show();
            } finally {
                bitmap.recycle(); removeRenderView(view);
            }
        }

        private void renderPdf(String html, Uri target, boolean sendToEpson, String paper) {
            final WebView v = makeRenderView();
            v.setVisibility(View.INVISIBLE);
            final int cssWidth = paper.equals("F4") ? 813 : 794;
            final int cssHeight = paper.equals("F4") ? 1247 : 1123;
            final float density = getResources().getDisplayMetrics().density;
            final int renderWidth = Math.round(cssWidth * density);
            final int renderHeight = Math.round(cssHeight * density);
            addContentView(v, new android.view.ViewGroup.LayoutParams(renderWidth, renderHeight));
            v.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) {
                    handler.postDelayed(() -> createPdfFromWebView(v, html, target, sendToEpson, paper), 500);
                }
            });
            v.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
        }

        private void createPdfFromWebView(WebView view, String html, Uri target, boolean sendToEpson, String paper) {
            // Render the HTML at CSS-pixel size multiplied by Android density.
            // This prevents high-density phones from cropping the right/bottom
            // part of the receipt when WebView is drawn into the PDF canvas.
            final int cssWidth = paper.equals("F4") ? 813 : 794;
            final int cssHeight = paper.equals("F4") ? 1247 : 1123;
            final float density = getResources().getDisplayMetrics().density;
            final int renderWidth = Math.round(cssWidth * density);
            final int contentHeight = Math.round(cssHeight * density);
            view.measure(View.MeasureSpec.makeMeasureSpec(renderWidth, View.MeasureSpec.EXACTLY),
                    View.MeasureSpec.makeMeasureSpec(contentHeight, View.MeasureSpec.EXACTLY));
            view.layout(0, 0, renderWidth, contentHeight);
            view.requestLayout();

            // One complete physical page: scale the entire HTML page to fit A4/F4.
            final int pageW = paper.equals("F4") ? 612 : 595;
            final int pageH = paper.equals("F4") ? 936 : 842;
            final float scale = Math.min(pageW / (float) renderWidth, pageH / (float) contentHeight);
            int pages = 1;
            PdfDocument pdf = new PdfDocument();
            try {
                for (int p = 0; p < pages; p++) {
                    PdfDocument.Page page = pdf.startPage(new PdfDocument.PageInfo.Builder(pageW, pageH, p + 1).create());
                    Canvas c = page.getCanvas();
                    c.drawColor(Color.WHITE);
                    c.save();
                    c.scale(scale, scale);
                    view.draw(c);
                    c.restore();
                    pdf.finishPage(page);
                }

                File dir = new File(getCacheDir(), "shared"); if (!dir.exists()) dir.mkdirs();
                File temp = new File(dir, "Buku-Nota-" + System.currentTimeMillis() + ".pdf");
                try (FileOutputStream out = new FileOutputStream(temp)) { pdf.writeTo(out); }
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", temp);

                if (target != null) {
                    try (java.io.OutputStream out = getContentResolver().openOutputStream(target)) {
                        java.io.InputStream in = new java.io.FileInputStream(temp);
                        byte[] buf = new byte[8192]; int n;
                        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                        in.close();
                    }
                    Toast.makeText(MainActivity.this, "PDF berhasil disimpan.", Toast.LENGTH_SHORT).show();
                } else if (sendToEpson) {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("application/pdf");
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    if (isPackageInstalled("epson.print")) {
                        send.setPackage("epson.print");
                        try { startActivity(send); }
                        catch (Exception e) { shareChooser(uri, "Kirim PDF nota ke Epson iPrint"); }
                    } else {
                        shareChooser(uri, "Kirim PDF nota ke Epson iPrint");
                    }
                }
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Gagal membuat PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
            } finally {
                pdf.close(); removeRenderView(view);
            }
        }

        private void shareChooser(Uri uri, String title) {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("application/pdf");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, title));
        }
        private void removeRenderView(View v) {
            if (v.getParent() instanceof android.view.ViewGroup) ((android.view.ViewGroup)v.getParent()).removeView(v);
        }
        private boolean isPackageInstalled(String packageName) {
            try { getPackageManager().getPackageInfo(packageName, 0); return true; }
            catch (Exception e) { return false; }
        }
    }
}
