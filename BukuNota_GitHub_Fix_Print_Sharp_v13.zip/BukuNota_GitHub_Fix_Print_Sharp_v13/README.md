# Buku Nota - Fix Print Full Page + High Quality v13

Perbaikan dari v12:
- Export gambar WhatsApp menjadi 2x resolusi (A4 1588x2246 px / F4 1626x2494 px).
- PDF dan Epson dirender pada 2x resolusi halaman sebelum disesuaikan ke ukuran A4/F4.
- HTML nota menggunakan zoom 2x hanya pada jalur export native agar teks, garis, tabel, logo, dan tanda tangan lebih tajam.
- Layout full-page v12 dipertahankan.

Build melalui GitHub Actions seperti versi sebelumnya.
