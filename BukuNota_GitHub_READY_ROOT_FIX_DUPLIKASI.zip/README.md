# Buku Nota - GitHub APK

Versi ini memperbaiki bug daftar nota yang sebelumnya dapat membuat beberapa record dengan nomor nota yang sama ketika nilai Ongkir/Bayar diubah. Sekarang nota disimpan satu kali saat Preview dibuka, lalu perubahan Ongkir/Bayar memperbarui nota yang sama. Data duplikat lama dengan nomor nota yang sama juga dibersihkan otomatis, dengan mempertahankan record terakhir.

Fitur lain yang dipertahankan:
- Portrait dan landscape responsif.
- Tombol Kontak HP di samping field kontak pelanggan.
- Logo dan tanda tangan dari Pengaturan.
- Preview dan cetak/simpan PDF.
- Penyimpanan nota di perangkat.

## Build di GitHub
Workflow `Build APK Buku Nota` dapat membangun proyek langsung dari root repository maupun dari ZIP proyek yang di-upload ke repository.
