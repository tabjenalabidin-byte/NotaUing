# Buku Nota - Android APK

Proyek Android WebView untuk aplikasi Buku Nota.

## Fitur
- HTML Buku Nota berjalan offline di Android.
- Logo dan tanda tangan dapat diatur dari aplikasi.
- Cetak / Simpan PDF menggunakan Android Print Framework.
- Tombol **📱 Kontak HP** di samping kolom Kontak pelanggan membuka pemilih kontak bawaan Android.
- Setelah memilih kontak, nomor telepon otomatis masuk ke kolom Kontak. Nama kontak juga otomatis mengisi kolom Nama jika kolom Nama masih kosong.

## Build di GitHub Actions
Workflow ada di `.github/workflows/build-apk.yml`.

APK debug akan tersedia sebagai artifact `BukuNota-APK` setelah workflow berhasil.
