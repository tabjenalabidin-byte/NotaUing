# Buku Nota APK — v10 Full Page A4/F4

Versi ini memperbaiki ukuran hasil Preview, gambar WhatsApp, PDF, dan cetak Epson agar benar-benar berupa **satu halaman penuh A4 atau F4**, bukan screenshot WebView yang melebar/terpotong.

## Ukuran halaman
- A4: 794 × 1123 px (rasio A4), PDF 595 × 842 pt
- F4: 813 × 1247 px (rasio F4), PDF 612 × 936 pt

## Perbaikan utama
- Gambar WhatsApp dibuat tepat satu halaman A4/F4.
- PDF dibuat tepat satu halaman A4/F4 dan seluruh halaman diskalakan agar muat.
- Cetak Epson menggunakan PDF halaman penuh.
- Preview memakai lebar halaman responsif agar tidak melebar keluar layar.
- Kolom pelanggan dan tabel menggunakan layout yang lebih aman agar tidak terpotong di sisi kanan.

Fitur sebelumnya tetap dipertahankan: Telusuri Kontak, logo/tanda tangan, Enter pindah field, draft otomatis, edit item/timbangan, A4/F4, WhatsApp, Simpan PDF, dan Cetak Epson.


## Revisi v5.1
- Layout mendukung portrait dan landscape.
- Dialog Tambah Item otomatis memfokuskan kursor ke Nama Item.
- Ikon aplikasi baru bertema nota/struk dan logo default pada nota diperbarui.
