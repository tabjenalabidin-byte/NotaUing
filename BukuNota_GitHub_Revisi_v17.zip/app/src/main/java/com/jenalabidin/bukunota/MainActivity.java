package com.jenalabidin.bukunota;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.pdf.PdfDocument;
import android.graphics.Color;
import android.net.Uri;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.os.ParcelFileDescriptor;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintDocumentInfo;
import android.print.PageRange;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.provider.ContactsContract;
import android.database.Cursor;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileOutputStream;

public class MainActivity extends Activity {
    private WebView webView;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private ValueCallback<Uri[]> filePathCallback;
    private static final int FILE_CHOOSER = 1001;
    private static final int CREATE_PDF = 1002;
    private static final int PICK_CONTACT = 1003;
    private String pendingPdfHtml;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        webView = new WebView(this);
        setContentView(webView);
        WebSettings ws = webView.getSettings();
        ws.setJavaScriptEnabled(true);
        ws.setDomStorageEnabled(true);
        ws.setAllowFileAccess(true);
        ws.setAllowContentAccess(true);
        ws.setBuiltInZoomControls(false);
        ws.setDisplayZoomControls(false);
        ws.setLoadWithOverviewMode(false);
        ws.setUseWideViewPort(false);
        ws.setSupportMultipleWindows(false);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (filePathCallback != null) filePathCallback.onReceiveValue(null);
                filePathCallback = callback;
                try {
                    Intent intent = params.createIntent();
                    intent.addCategory(Intent.CATEGORY_OPENABLE);
                    startActivityForResult(intent, FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    filePathCallback = null;
                    Toast.makeText(MainActivity.this, "Tidak bisa membuka pemilih gambar.", Toast.LENGTH_SHORT).show();
                    return false;
                }
            }
        });
        webView.addJavascriptInterface(new PrintBridge(this), "AndroidPrint");
        webView.addJavascriptInterface(new ContactsBridge(), "AndroidContacts");
        webView.loadUrl("file:///android_asset/index.html");
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_CHOOSER && filePathCallback != null) {
            Uri[] results = WebChromeClient.FileChooserParams.parseResult(resultCode, data);
            filePathCallback.onReceiveValue(results);
            filePathCallback = null;
        } else if (requestCode == CREATE_PDF && resultCode == RESULT_OK && data != null && data.getData() != null && pendingPdfHtml != null) {
            final Uri target = data.getData();
            final String packed = pendingPdfHtml;
            pendingPdfHtml = null;
            String html = packed; String paper = "A4";
            int marker = packed.lastIndexOf("<!--PAPER:");
            if(marker >= 0){ int end = packed.indexOf("-->", marker); if(end > marker){ paper = packed.substring(marker+10,end); html = packed.substring(0,marker); }}
            new PrintBridge(MainActivity.this).renderPdf(html, target, false, paper);
        } else if (requestCode == CREATE_PDF) {
            pendingPdfHtml = null;
        } else if (requestCode == PICK_CONTACT && resultCode == RESULT_OK && data != null && data.getData() != null) {
            fillSelectedContact(data.getData());
        }
    }

    @Override protected void onDestroy() {
        if (filePathCallback != null) { filePathCallback.onReceiveValue(null); filePathCallback = null; }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    public class ContactsBridge {
        @JavascriptInterface public void pickContact() {
            runOnUiThread(() -> {
                try {
                    Intent intent = new Intent(Intent.ACTION_PICK, ContactsContract.CommonDataKinds.Phone.CONTENT_URI);
                    intent.addCategory(Intent.CATEGORY_DEFAULT);
                    startActivityForResult(intent, PICK_CONTACT);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Tidak bisa membuka daftar kontak.", Toast.LENGTH_SHORT).show();
                }
            });
        }
    }

    private void fillSelectedContact(Uri uri) {
        Cursor cursor = null;
        try {
            String[] projection = new String[]{
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            };
            cursor = getContentResolver().query(uri, projection, null, null, null);
            if (cursor != null && cursor.moveToFirst()) {
                int nameIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME);
                int numberIdx = cursor.getColumnIndex(ContactsContract.CommonDataKinds.Phone.NUMBER);
                String name = nameIdx >= 0 ? cursor.getString(nameIdx) : "";
                String number = numberIdx >= 0 ? cursor.getString(numberIdx) : "";
                String js = "window.setContactFromAndroid(" +
                        org.json.JSONObject.quote(name == null ? "" : name) + "," +
                        org.json.JSONObject.quote(number == null ? "" : number) + ");";
                webView.evaluateJavascript(js, null);
            }
        } catch (Exception e) {
            Toast.makeText(this, "Gagal mengambil data kontak.", Toast.LENGTH_SHORT).show();
        } finally {
            if (cursor != null) cursor.close();
        }
    }

    public class PrintBridge {
        private final Context context;
        PrintBridge(Context context) { this.context = context; }

        @JavascriptInterface public void printPdf(final String html, final String paper) {
            runOnUiThread(() -> {
                // Epson iPrint accepts PDF documents. We create a real A4 PDF instead of
                // sending a very tall PNG, avoiding the 10x15-photo scaling/cropping seen before.
                renderPdf(html, null, true, paper);
            });
        }

        @JavascriptInterface public void shareImage(final String html, final String paper) {
            runOnUiThread(() -> renderImage(html, paper));
        }

        @JavascriptInterface public void savePdf(final String html, final String paper) {
            runOnUiThread(() -> {
                pendingPdfHtml = html + "\n<!--PAPER:" + paper + "-->";
                Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                i.addCategory(Intent.CATEGORY_OPENABLE);
                i.setType("application/pdf");
                i.putExtra(Intent.EXTRA_TITLE, "Buku-Nota.pdf");
                try { startActivityForResult(i, CREATE_PDF); }
                catch (Exception e) { pendingPdfHtml = null; Toast.makeText(MainActivity.this, "Tidak bisa membuka penyimpanan PDF.", Toast.LENGTH_LONG).show(); }
            });
        }

        private WebView makeRenderView() {
            WebView v = new WebView(MainActivity.this);
            WebSettings ws = v.getSettings();
            ws.setJavaScriptEnabled(true);
            ws.setDomStorageEnabled(false);
            ws.setAllowFileAccess(true);
            ws.setAllowContentAccess(true);
            ws.setDefaultTextEncodingName("UTF-8");
            v.setBackgroundColor(Color.WHITE);
            return v;
        }

        private void renderImage(String html, String paper) {
            final WebView v = makeRenderView();
            final int pageWidth = paper.equals("F4") ? 813 : 794;
            final int pageHeight = paper.equals("F4") ? 1247 : 1123;
            v.setVisibility(View.VISIBLE);
            v.setTranslationX(-(pageWidth + 20));
            addContentView(v, new android.view.ViewGroup.LayoutParams(pageWidth, pageHeight));
            v.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) {
                    handler.postDelayed(() -> captureFullImage(v, paper, pageWidth, pageHeight), 500);
                }
            });
            v.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
        }

        private void captureFullImage(final WebView view, final String paper, final int pageWidth, final int pageHeight) {
            final String js = "(function(){return document.querySelectorAll('.receipt-page').length||1;})()";
            view.evaluateJavascript(js, value -> {
                int pageCount = 1;
                try { pageCount = Math.max(1, Integer.parseInt(value.replaceAll("[^0-9]", ""))); } catch (Exception ignored) {}
                final int contentHeight = pageCount * pageHeight;
                view.measure(View.MeasureSpec.makeMeasureSpec(pageWidth, View.MeasureSpec.EXACTLY),
                        View.MeasureSpec.makeMeasureSpec(contentHeight, View.MeasureSpec.EXACTLY));
                view.layout(0, 0, pageWidth, contentHeight);
                Bitmap full = Bitmap.createBitmap(pageWidth, contentHeight, Bitmap.Config.ARGB_8888);
                Canvas canvas = new Canvas(full);
                canvas.drawColor(Color.WHITE);
                view.draw(canvas);
                java.util.ArrayList<Uri> uris = new java.util.ArrayList<>();
                try {
                    File dir = new File(getCacheDir(), "shared"); if (!dir.exists()) dir.mkdirs();
                    for (int i=0;i<pageCount;i++) {
                        int top=i*pageHeight;
                        int bottom=Math.min(top+pageHeight, full.getHeight());
                        Bitmap pageBitmap=Bitmap.createBitmap(full,0,top,pageWidth,bottom-top);
                        File file=new File(dir,"Buku-Nota-"+System.currentTimeMillis()+"-"+(i+1)+".png");
                        try(FileOutputStream out=new FileOutputStream(file)){pageBitmap.compress(Bitmap.CompressFormat.PNG,100,out);}
                        pageBitmap.recycle();
                        uris.add(FileProvider.getUriForFile(MainActivity.this,getPackageName()+".fileprovider",file));
                    }
                    Intent share = new Intent(Intent.ACTION_SEND_MULTIPLE);
                    share.setType("image/png");
                    share.putParcelableArrayListExtra(Intent.EXTRA_STREAM, uris);
                    share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    startActivity(Intent.createChooser(share, "Bagikan nota sebagai gambar"));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Gagal membuat gambar nota: " + e.getMessage(), Toast.LENGTH_LONG).show();
                } finally {
                    if (!full.isRecycled()) full.recycle();
                    removeRenderView(view);
                }
            });
        }

        private void renderPdf(String html, Uri target, boolean sendToEpson, String paper) {
            final WebView v = makeRenderView();
            final int renderWidth = paper.equals("F4") ? 813 : 794;
            final int renderHeight = paper.equals("F4") ? 1247 : 1123;
            v.setVisibility(View.VISIBLE);
            v.setTranslationX(-(renderWidth + 40));
            addContentView(v, new android.view.ViewGroup.LayoutParams(renderWidth, renderHeight));
            v.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView view, String url) {
                    handler.postDelayed(() -> prepareFullPagePdf(v, target, sendToEpson, paper, renderWidth, renderHeight), 700);
                }
            });
            v.loadDataWithBaseURL("file:///android_asset/", html, "text/html", "UTF-8", null);
        }

        private void prepareFullPagePdf(final WebView view, final Uri target, final boolean sendToEpson,
                                        final String paper, final int pageWidth, final int pageHeight) {
            // The HTML sent by index.html already contains physical .receipt-page
            // elements, each exactly one A4/F4 page tall. Do not paginate by
            // arbitrary viewport/row positions; that was the source of the
            // cropped/oversized output in the previous versions.
            final String js = "(function(){var pages=document.querySelectorAll('.receipt-page').length;" +
                    "return JSON.stringify({pages:pages,height:Math.max(document.body.scrollHeight,document.documentElement.scrollHeight)});})()";
            view.evaluateJavascript(js, value -> {
                try {
                    String json = value == null ? "" : value;
                    if (json.startsWith("\"") && json.endsWith("\"")) json = new org.json.JSONTokener(json).nextValue().toString();
                    org.json.JSONObject obj = new org.json.JSONObject(json);
                    int pageCount = Math.max(1, obj.optInt("pages", 1));
                    final int contentHeight = pageCount * pageHeight;

                    view.measure(View.MeasureSpec.makeMeasureSpec(pageWidth, View.MeasureSpec.EXACTLY),
                            View.MeasureSpec.makeMeasureSpec(contentHeight, View.MeasureSpec.EXACTLY));
                    view.layout(0, 0, pageWidth, contentHeight);
                    Bitmap bitmap = Bitmap.createBitmap(pageWidth, contentHeight, Bitmap.Config.ARGB_8888);
                    Canvas canvas = new Canvas(bitmap);
                    canvas.drawColor(Color.WHITE);
                    view.draw(canvas);
                    writePagedPdf(bitmap, pageWidth, pageHeight, pageCount, target, sendToEpson, view, paper);
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Gagal menyiapkan halaman PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
                    removeRenderView(view);
                }
            });
        }

        private void writePagedPdf(Bitmap bitmap, int bitmapWidth, int pageHeightPx, int pageCount,
                                   Uri target, boolean sendToEpson, WebView view, String paper) {
            PdfDocument pdf = null;
            File temp = null;
            try {
                final int pdfWidth = paper.equals("F4") ? 612 : 595;
                final int pdfHeight = paper.equals("F4") ? 936 : 842;
                final float scale = pdfWidth / (float) bitmapWidth;

                pdf = new PdfDocument();
                for (int pageIndex = 0; pageIndex < pageCount; pageIndex++) {
                    int top = pageIndex * pageHeightPx;
                    int bottom = Math.min(top + pageHeightPx, bitmap.getHeight());
                    if (bottom <= top) break;

                    PdfDocument.PageInfo info = new PdfDocument.PageInfo.Builder(pdfWidth, pdfHeight, pageIndex + 1).create();
                    PdfDocument.Page page = pdf.startPage(info);
                    Canvas pc = page.getCanvas();
                    pc.drawColor(Color.WHITE);
                    android.graphics.Rect src = new android.graphics.Rect(0, top, bitmapWidth, bottom);
                    android.graphics.RectF dst = new android.graphics.RectF(0, 0, pdfWidth, pdfHeight);
                    pc.drawBitmap(bitmap, src, dst, null);
                    pdf.finishPage(page);
                }

                File dir = new File(getCacheDir(), "shared");
                if (!dir.exists()) dir.mkdirs();
                temp = new File(dir, "Buku-Nota-" + System.currentTimeMillis() + ".pdf");
                try (FileOutputStream out = new FileOutputStream(temp)) { pdf.writeTo(out); }
                finishPdfExport(temp, target, sendToEpson, view);
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Gagal membuat PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
                if (temp != null) temp.delete();
                removeRenderView(view);
            } finally {
                if (pdf != null) { try { pdf.close(); } catch (Exception ignored) {} }
                if (bitmap != null && !bitmap.isRecycled()) bitmap.recycle();
            }
        }

        private void finishPdfExport(File temp, Uri target, boolean sendToEpson, WebView view) {
            try {
                Uri uri = FileProvider.getUriForFile(MainActivity.this, getPackageName() + ".fileprovider", temp);
                if (target != null) {
                    try (java.io.OutputStream out = getContentResolver().openOutputStream(target);
                         java.io.InputStream in = new java.io.FileInputStream(temp)) {
                        byte[] buf = new byte[8192]; int n;
                        while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
                    }
                    Toast.makeText(MainActivity.this, "PDF berhasil disimpan.", Toast.LENGTH_SHORT).show();
                } else if (sendToEpson) {
                    Intent send = new Intent(Intent.ACTION_SEND);
                    send.setType("application/pdf");
                    send.putExtra(Intent.EXTRA_STREAM, uri);
                    send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    if (isPackageInstalled("epson.print")) {
                        send.setPackage("epson.print");
                        try { startActivity(send); }
                        catch (Exception e) { shareChooser(uri, "Kirim PDF nota ke Epson iPrint"); }
                    } else {
                        shareChooser(uri, "Kirim PDF nota ke Epson iPrint");
                    }
                }
            } catch (Exception e) {
                Toast.makeText(MainActivity.this, "Gagal mengekspor PDF: " + e.getMessage(), Toast.LENGTH_LONG).show();
            } finally {
                removeRenderView(view);
            }
        }

        private void shareChooser(Uri uri, String title) {
            Intent share = new Intent(Intent.ACTION_SEND);
            share.setType("application/pdf");
            share.putExtra(Intent.EXTRA_STREAM, uri);
            share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            startActivity(Intent.createChooser(share, title));
        }
        private void removeRenderView(View v) {
            if (v.getParent() instanceof android.view.ViewGroup) ((android.view.ViewGroup)v.getParent()).removeView(v);
        }
        private boolean isPackageInstalled(String packageName) {
            try { getPackageManager().getPackageInfo(packageName, 0); return true; }
            catch (Exception e) { return false; }
        }
    }
}
