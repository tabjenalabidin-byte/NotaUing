# Buku Nota APK — v5.2 Full Page A4/F4

Versi ini memperbaiki ukuran hasil Preview, gambar WhatsApp, PDF, dan cetak Epson agar benar-benar berupa **satu halaman penuh A4 atau F4**, bukan screenshot WebView yang melebar/terpotong.

## Ukuran halaman
- A4: 794 × 1123 px (rasio A4), PDF 595 × 842 pt
- F4: 813 × 1247 px (rasio F4), PDF 612 × 936 pt

## Perbaikan utama
- Gambar WhatsApp dibuat tepat satu halaman A4/F4.
- PDF dibuat tepat satu halaman A4/F4 dan seluruh halaman diskalakan agar muat.
- Cetak Epson menggunakan PDF halaman penuh.
- Preview memakai lebar halaman responsif agar tidak melebar keluar layar.
- Kolom pelanggan dan tabel menggunakan layout yang lebih aman agar tidak terpotong di sisi kanan.

Fitur sebelumnya tetap dipertahankan: Telusuri Kontak, logo/tanda tangan, Enter pindah field, draft otomatis, edit item/timbangan, A4/F4, WhatsApp, Simpan PDF, dan Cetak Epson.


## Revisi v5.2
- Perbaikan hasil gambar WhatsApp agar seluruh halaman A4/F4 tidak terpotong karena WebView sebelumnya berada di container setinggi 100px.
- Perbaikan Simpan PDF dan Cetak Epson dengan render WebView setinggi halaman penuh.
- Saat menekan Enter pada kolom Harga item, aplikasi otomatis menjalankan tombol Tambah.

## Revisi v5.1
- Layout mendukung portrait dan landscape.
- Dialog Tambah Item otomatis memfokuskan kursor ke Nama Item.
- Ikon aplikasi baru bertema nota/struk dan logo default pada nota diperbarui.


Revisi 5.5: output PDF/cetak sekarang menghitung tinggi nota penuh dan membuat halaman lanjutan otomatis tanpa memotong baris tabel.

## Revisi 5.8.1 – Perbaikan Print & Share

Perbaikan utama pada rendering nota native Android:
- Setiap halaman nota dirender satu per satu pada viewport A4/F4 yang tetap.
- Print PDF tidak lagi menggambar seluruh dokumen menjadi satu WebView yang sangat tinggi.
- Share gambar juga merender setiap halaman secara terpisah.
- Mencegah hasil print/share hanya menampilkan logo dan nama perusahaan akibat clipping WebView.
- Preview HTML dan ukuran halaman native tetap menggunakan dimensi A4/F4 yang sama.
