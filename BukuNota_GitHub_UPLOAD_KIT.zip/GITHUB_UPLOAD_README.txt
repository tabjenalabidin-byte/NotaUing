BUKU NOTA - CARA UPLOAD KE GITHUB

Jika GitHub tidak bisa upload folder:
1. Buat repository kosong di GitHub.
2. Upload file BukuNota_GitHub_READY_ROOT.zip ke repository.
3. Upload file .github/workflows/build-apk.yml dari proyek ini (buat folder/file melalui Add file > Create new file jika perlu).
4. Untuk cara paling mudah, gunakan GitHub Codespaces/desktop untuk mengekstrak ZIP ke root repository.

Alternatif dari PC/Termux:
  unzip BukuNota_GitHub_READY_ROOT.zip -d BukuNota
  cd BukuNota
  git init
  git add .
  git commit -m "Initial Buku Nota APK project"
  git branch -M main
  git remote add origin https://github.com/USERNAME/REPO.git
  git push -u origin main
